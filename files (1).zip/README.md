# Robust Forum Website & Admin Panel

## Features

**Admin Panel:**
- Add, edit, delete, ban, unban users
- User role assignment: `super_admin`, `admin`, `editor`, `user`
- User profile management: bio, contact, language
- View user activity logs
- Ban users (pre-written or custom reasons, timed bans, unban history)
- User notifications for admin actions
- Full moderation: flag posts/replies, soft delete, audit logging

**Forum:**
- Prominent topics shown to visitors
- Full topics/replies available to logged-in users
- Topic/reply CRUD for admins and authors
- Signup/login panel (first account is `super_admin`)
- All account/profile data stored in MongoDB

---

## Setup Instructions

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/forum-admin-panel.git
cd forum-admin-panel
```

### 2. Backend Setup

```bash
cd backend
npm install
```

- Create a `.env` file with:
  ```
  MONGO_URI=mongodb://localhost:27017/forum
  JWT_SECRET=your_jwt_secret
  ```
- Start backend:
  ```bash
  npm start
  ```
  Server runs on `localhost:3000`

### 3. Frontend Setup

```bash
cd ../frontend
npm install
npm start
```
  Runs on `localhost:3001` (by default)

### 4. Create first user

- Visit `http://localhost:3001/signup`
- First account becomes `super_admin` with full admin access.

### 5. Usage

- Admin Panel: `/admin`
- Forum: `/`
- Profiles: `/profile/:id`
- Topics: `/topic/:id`

---

## File Map

- backend/
  - app.js
  - .env
  - models/
    - User.js
    - Post.js
  - middleware/
    - auth.js
    - roles.js
  - routes/
    - auth.js
    - users.js
    - forum.js
- frontend/
  - src/
    - App.jsx
    - components/
      - Navbar.jsx
      - SignupForm.jsx
      - LoginForm.jsx
      - ForumTopics.jsx
      - TopicDetail.jsx
      - AdminPanel.jsx
      - UserEditor.jsx
      - BanModal.jsx
      - ActivityLog.jsx
      - PostModeration.jsx
      - ReplyModeration.jsx

---

## Extra Moderation Features

- **Flagging queue:** Admins can view and resolve flagged posts/replies (`PostModeration.jsx`, `ReplyModeration.jsx`)
- **Soft delete:** All delete actions are reversible by admins
- **Audit log:** Tracks all admin actions, visible in admin panel
- **Notification system:** Users receive notifications for bans, flags, deletes
- **Ban/unban history:** Full history tracked per user

---

## Next Steps

- Expand UI for error handling, validation, notification popups
- Add password reset/email verification
- Add tests for backend and frontend